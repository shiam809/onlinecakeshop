For demonstration purpose, Some screenshots and a video link have been provided. 
Please check for further details.

This youtube link is the demonstration video of the project. 

Link- https://www.youtube.com/watch?v=gt1rqbqgEZ8

---Contact Here if needed---
Abdullah Mahmood
abdullah.mahmood@northsouth.edu
01788810008

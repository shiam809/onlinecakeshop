
<div class="col-md-3">
    <p class="lead">Cakes Categories</p>
    <div class="list-group">


    	<?php
        //from function
    		get_categories();

    	 ?>

       <div>

         <h4 class="text-left"> <?php display_message(); ?>  </h4>
         <?php search_cake(); ?>

       </div>

    </div>
</div>

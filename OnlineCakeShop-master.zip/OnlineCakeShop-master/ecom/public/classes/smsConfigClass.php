<?php

class smsClass {

  const ACCOUNT_SID = 'AC9183e4d4d466b985e7b32e7eadad3187';

  const AUTH_TOKEN = '4347203788c8e49676cef79849793bcb';

  const TWILIO_NUMBER = '+16468465193';


}





 ?>

<?php

class LoginClass {

  const SMTP_HOST = 'smtp.gmail.com';

  const SMTP_USER = 'abimahmood16@gmail.com';

  const SMTP_PASSWORD = 'test5226';

  const SMTP_PORT = 465;

  const MAIL_FROM = "CakeShop";


}



class ContactUs {

  const SMTP_HOST = 'smtp.gmail.com';              // Specify main and backup SMTP servers

  const SMTP_USER = 'abimahmood16@gmail.com';      // SMTP username

  const SMTP_PASSWORD = 'test5226';                // SMTP password

  const SMTP_PORT = 465;                           //Gmail SMTP port, TCP port to connect to

  const MAIL_TO = 'abimahmood.bd@gmail.com';       // Add a recipient who will get the Email




}



 ?>

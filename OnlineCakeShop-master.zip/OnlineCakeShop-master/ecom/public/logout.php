<?php require_once("../resources/config.php"); ?>


<?php


logged_out(); // cookie expires







 ?>

<?php require_once("../resources/config.php"); ?>
<?php include(TEMPLATE_FRONT . DS . "header.php") ?>
<?php include(TEMPLATE_FRONT . DS . "top_nav.php") ?>

  <div class="container">




<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>

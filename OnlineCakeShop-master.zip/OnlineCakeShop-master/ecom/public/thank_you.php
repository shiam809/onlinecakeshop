<?php require_once("../resources/config.php"); ?>
<?php include(TEMPLATE_FRONT . DS . "header.php") ?>
<?php include(TEMPLATE_FRONT . DS . "top_nav.php") ?>


<?php process_transaction(); ?> <!-- from cart.php -->

<!-- Page Content -->
<div class="container">

  <h1 class="text-center">THANK YOU</h1>

</div>
    <!-- /.container -->



<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>
